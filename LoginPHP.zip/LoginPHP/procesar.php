<?php


$Idcliente = $_POST['Idcliente'];
$Nombre = $_POST['Nombre'];
$Apellido = $_POST['Apellido'];
$Direccion = $_POST['Direccion'];
$NombreProducto = $_POST['NombreProducto'];



echo "Recibimos... <br>";
echo "idcliente: ".$Idcliente."<br>";
echo "Nombre: ".$Nombre."<br>";
echo "Apellido: ".$Apellido."<br>";
echo "Dirección: ".$Direccion."<br>";
echo "Nombre Producto: ".$NombreProducto."<br>";
