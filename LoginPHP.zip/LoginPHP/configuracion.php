<?php
$server = "localhost";
$user= "id14177477_restaurante20";
$pass= "Foodbot_2020";
$bd="id14177477_restaurante";



 ?>